from django.conf.urls import url
from django.contrib.auth.views import login
from . import views
from django.urls import path

app_name ="users"

urlpatterns = [
	# Login page
	url(r'^login/$', login, {'template_name': 'users/login.html'},name='login'),
	# Logout page
	url(r'^logout/$', views.logout_view, name='logout'),
	# Registration page
	url(r'^register/$', views.register, name='register'),
	#Activate page
	#url(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',views.activate, name='activate')

	#url(r'^activate/(?P<uidb64>\d+)/(?P<token>\d+)/$',views.activate, name='activate')

	path('activate/<uidb64>/<token>/',views.activate, name='activate')
]